
package com.Atmrogramming;

import jdk.nashorn.internal.objects.annotations.Setter;

public class ATM {
    private double balance;
    private double depositAmount;
    private double withdrawAmount;


    public ATM(){

    }



    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(double withdrawAmount) {
        this.withdrawAmount = withdrawAmount;
    }

    public double getWithdrawAmount() {

        return withdrawAmount;
    }

    public void setWithdrawAmount(double withdrawAmount) {

        this.withdrawAmount = withdrawAmount;
    }
}
